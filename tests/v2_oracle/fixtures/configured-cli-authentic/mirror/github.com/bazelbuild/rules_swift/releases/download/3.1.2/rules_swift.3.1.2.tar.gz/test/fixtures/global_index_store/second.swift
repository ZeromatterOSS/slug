func second() {
    print("second")
}
