void nested_duplicate() {}
