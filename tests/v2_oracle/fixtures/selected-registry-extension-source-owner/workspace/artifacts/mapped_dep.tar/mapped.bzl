MAPPED = "mapped"
